clear
clc

width = 8;
depth = 1024;

fid = fopen('d_dds.mif','w');

fprintf(fid,'--made in xiaozhang\n');
fprintf(fid,'--made in xiaozhang\n');

fprintf(fid,'WIDTH=%d;\n',width);
fprintf(fid,'DEPTH=%d;\n',depth);

fprintf(fid,'ADDRESS_RADIX=UNS;\n');
fprintf(fid,'DATA_RADIX=UNS;\n');

fprintf(fid,'CONTENT BEGIN\n');

for i = 0 : depth - 1
    if i < 256 
       a = floor(sin(2*pi*i/256) * 0.5 * 255);
    else 
        if i < 512
           if i <= 256 + 127
              a = 127;
           else
               a = -128;
           end
        else 
            if i < 760
               a = -128 + i - 512; 
            else
                if i <= 768 + 127
                    a = -128 + (i - 768) * 2;
                else
                    a = 127 - (i - 768 - 128) * 2;
                end
            end
        end
        
    end
    
    if a>= 0
        fprintf(fid,'%d : %d;\n',i,a);
    else
        fprintf(fid,'%d : %d;\n',i,a+256);
    end
end

fprintf(fid,'END;\n');
